int dectobin();
int dectohex();
int dectooct();
